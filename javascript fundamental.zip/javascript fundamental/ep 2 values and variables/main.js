//declaring variables
let box1 = "shoes";
box2 = "clothes";

console.log(box1);
console.log(box2);

//Re-assign variables
let box3 = "books";
console.log(box3);

box3 = "awards";
console.log(box3);
console.log(box3);

//let, const, var
let food = "rice";
const drink = "cola";
// var utencil = "spoon"; Never ever use var because it is a legacy

//Naming convenion
const Food = "food"; // should not be used
//const 3years = 'age'; // should not be used
const _food = "food"; // can be used
const $food = "food"; // can be used

//const new = "new car"; // should not be used
const studentageageinss1 = "21";
const student_age_in_ss1 = "21";
const studentAgeInSs1 = "21"; //camel case 
