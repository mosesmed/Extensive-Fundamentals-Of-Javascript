//Type Conversion
/*let age = '21';
console.log(typeof age);

let birthYear = prompt("How old are you");

console.log(birthYear, typeof birthYear);
console.log(birthYear + " " + 18);

let x = Number(birthYear);
console.log(x, typeof x);
console.log(x + 18); */

/*let myNumber =234790987;
console.log(myNumber, typeof myNumber);
console.log (myNumber * 0);

let numConv = String(myNumber);
console.log(numConv, typeof numConv);
console.log (numConv + 0);*/

//Type Coersion
let myNumber = "21";
console.log(typeof myNumber, myNumber - 3);

let x = Number('Moses');
console.log(x - 2);

//Logic Operators
// And(&&) Or(||) Not(!)

let food = true;
console.log(typeof food, food)
let mine = !food;
console.log(typeof mine, mine);
let age;
console.log(Boolean(age), typeof age);

