'use strict';

//array
const moses = [
    'Moses', 
    'Med', 
    25, 
    1998, 
    'Male'
];
console.log(moses[0]);
console.log(moses);

//object
const profile = {
    firstName: 'Moses',
    lastName: 'Med',
    age: 25,
    birthYear: 1998,
    gender: 'Male'
};

console.log(profile.firstName);
console.log(profile);