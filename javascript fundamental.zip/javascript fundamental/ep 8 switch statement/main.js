let day = prompt('What day is it today');

//switch
switch(day){
    case 'Monday':
        console.log('Eat rice');
        break;
    case 'Tuesday':
        console.log('Eat beans');
        break;
    case 'Wednesday':
        console.log('Eat Oat');
        break;
    case 'Thursday':
        console.log('Fast');
        break;
    case 'Friday':
        console.log('Eat Lettuce');
        break;
    case 'Saturday':
        console.log('Eat bread');
        break;
    case 'Sunday':
        console.log('Eat Carrot');
    default:
        console.log('Please input a day');
}

//If Else statement
/*
if (day === 'Monday'){
    console.log('Eat rice');
}else if(day === 'Tuesday'){
    console.log('Eat beans');
}else if(day === 'Wednesday'){
    console.log('Eat Oat');
}else if (day === 'Thursday'){
    console.log('Fast');
}else if (day === 'Friday'){
    console.log('Eat lettuce');
}else if (day === 'Saturday'){
    console.log('Eat bread');
}else if(day === 'Sunday'){
    console.log('Eat carrot');
}else {
    console.log('Input a day please');
}*/