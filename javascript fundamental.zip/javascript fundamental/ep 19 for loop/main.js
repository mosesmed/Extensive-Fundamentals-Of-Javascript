
for (let rep = 1; rep <= 100; rep++){
    console.log(`Do rep ${rep}`);
}