'use strict';

//while loop
let rep = 1;
while (rep <= 10){
    console.log(`Do rep ${rep}`);
    rep++;
}

console.log('-----FOR LOOP-----')

//for loop
for(let repx = 1; repx <= 10; repx++){
    console.log(`Do rep ${repx}`);
};
