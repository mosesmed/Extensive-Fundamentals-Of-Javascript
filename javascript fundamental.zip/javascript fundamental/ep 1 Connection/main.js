// alert("This is my first line of code");
console.log("Hello World");

console.log("my name is moses");
