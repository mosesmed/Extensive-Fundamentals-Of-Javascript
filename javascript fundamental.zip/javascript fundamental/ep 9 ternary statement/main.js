let personAge = 20;

if (personAge >= 18 ){
    console.log("You're old enough");
}else{
    console.log("you're not old enough");
}

//ternary operator

personAge >= 18 ? console.log("You're old enough") : console.log("You're not old enough");

