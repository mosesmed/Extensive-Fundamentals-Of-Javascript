const birthYear = 1998;
const currentYear = 2023;

// find the current age of the user
console.log(currentYear - birthYear);

console.log (15 + 15);

console.log(5 * 2);

console.log(5 ** 2);

console.log(50/5);

console.log(5 + 5 * 10/2)

//BODMAS - bracket, of, division, multiplication, addition, subtraction

const cal = ((5 + 5) * 10 )/2
console.log (cal);

const mathewAge = 20;
const simonAge = 25;

console.log(mathewAge > simonAge);
console.log(mathewAge < simonAge);
console.log (mathewAge >= simonAge);
console.log (mathewAge <= simonAge);

console.log("Mathew is" + " " + mathewAge + " " + " years old"); //concatenation using the + sign

console.log(`Mathew is ${mathewAge} years old`); // Template literal: ${} is used to identify variables