'use strict';

document.querySelector('.headone').textContent = 'Manipulate H1 Now!!';

document.querySelector('.para').textContent = 'I gotcha now!!';

document.querySelector('.moses').value = "You're hacked";

document.querySelector('.moses2').value = 30;